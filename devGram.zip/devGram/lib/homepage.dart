import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import 'model/repo.dart';

class HomeScreen extends StatelessWidget {


  final _key = GlobalKey<ScaffoldState>();
  final dio = Dio(BaseOptions(baseUrl: 'https://dummyreddit.glitch.me'));

  HomeScreen({
    required Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      initialIndex: 0,
      child: Scaffold(
        key: _key,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.perm_identity),
            onPressed: () {
              _key.currentState!.openDrawer();
            },
          ),
          title: Container(
            padding: const EdgeInsets.all(5),
            decoration: BoxDecoration(
                color: Colors.grey[100],
                borderRadius: const BorderRadius.all(
                  Radius.circular(10),
                )),
            child: Row(
              children: const <Widget>[
                Icon(
                  Icons.search,
                  color: Colors.grey,
                ),
                Text(
                  "Search",
                  style: TextStyle(color: Colors.grey),
                ),
              ],
            ),
          ),
          bottom: const TabBar(
            tabs: <Widget>[
              Text(
                "Home",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
              ),
              Text(
                "Popular",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
              )
            ],
          ),
          elevation: 1,
          titleSpacing: 1,
        ),
        drawer: Drawer(
          child: Center(
            child: ElevatedButton(
              child: const Text("Close Drawer"),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ),
        ),
        body: TabBarView(
          children: <Widget>[
            const HomeTab(),
            //TODO show reddit post as well as repositories here
            Center(

                child: ListView.builder(
                  itemCount: 100,
                  itemBuilder: (context, i) {
                    //TODO show repositories here
                    return Card(
                      child: FutureBuilder(
                        future: dio.get('/posts', queryParameters: {'index': i}),
                        builder: (context, snapshot) {
                          if (!snapshot.hasData) {
                            return const SizedBox(
                              height: 300,
                              child: Center(child: CircularProgressIndicator()),
                            );
                          }
                          // snapshot.data has a dio response object
                          Response? response = snapshot.data as Response?;
                          Map<String, dynamic> data = response?.data;

                          return InkWell(
                            onTap: () => Navigator.of(context).pushNamed('/post'),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              children: <Widget>[
                                Row(
                                  children: <Widget>[
                                    const Icon(Icons.face),
                                    Expanded(
                                        child: Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Text("r/${data['by']}"),
                                        )),
                                    const Icon(Icons.more_vert)
                                  ],
                                ),
                                Text(data['description']),
                                Container(
                                  height: 200,
                                  color: Colors.grey[100],
                                  child: Image.network(
                                    data['image'],
                                    width: double.infinity,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(10),
                                  child: Row(
                                    children: <Widget>[
                                      Expanded(
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: const <Widget>[
                                            Icon(
                                              Icons.arrow_downward,
                                              color: Colors.grey,
                                            ),
                                            Text("Vote"),
                                            Icon(
                                              Icons.arrow_upward,
                                              color: Colors.grey,
                                            ),
                                          ],
                                        ),
                                      ),
                                      Expanded(
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: <Widget>[
                                            const Icon(
                                              Icons.message,
                                              color: Colors.grey,
                                            ),
                                            const SizedBox(width: 8),
                                            Text(data['comments'].toString()),
                                          ],
                                        ),
                                      ),
                                      Expanded(
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: const <Widget>[
                                            Icon(
                                              Icons.reply,
                                              color: Colors.grey,
                                            ),
                                            Text("Share"),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                )
                              ],
                            ),
                          );
                        },
                      ),
                    );
                  },
                )
            ),
          ],
        ),
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: 0,
          onTap: (index) {
            if (index == 2) {
              showModalBottomSheet(
                context: context,
                builder: (context) {
                  return Theme(
                    data: ThemeData.dark(),
                    child: DefaultTextStyle(
                      style: const TextStyle(color: Colors.white),
                      child: Container(
                        padding: const EdgeInsets.all(10),
                        decoration: const BoxDecoration(color: Colors.blue
                          // border: RoundedRectangleBorder()
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            const Text("Post to Reddit"),
                            Row(
                                mainAxisAlignment:
                                MainAxisAlignment.spaceEvenly,
                                children: List.generate(4, (i) {
                                  return Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: <Widget>[
                                      IconButton(
                                        icon: const Icon(
                                          Icons.device_unknown,
                                        ),
                                        onPressed: () {},
                                      ),
                                      const Text("????")
                                    ],
                                  );
                                })),
                            const CloseButton() // inbuilt
                          ],
                        ),
                      ),
                    ),
                  );
                },
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              );
            }
          },
          type: BottomNavigationBarType.fixed,
          showSelectedLabels: false,
          showUnselectedLabels: false,
          selectedItemColor: Colors.black,
          items: [
            const BottomNavigationBarItem(
                icon:  Icon(Icons.blur_circular), label: ""),
            const BottomNavigationBarItem(icon: Icon(Icons.apps), label: ""),
            BottomNavigationBarItem(
                icon: Container(
                  padding: const EdgeInsets.all(2),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.blue, width: 2),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.edit),
                ),
                label: ""),
            const BottomNavigationBarItem(icon: Icon(Icons.message), label: ""),
            const BottomNavigationBarItem(icon:  Icon(Icons.email), label: ""),
          ],
        ),
      ),
    );
  }
}

// Home Tab
class HomeTab extends StatefulWidget {
  const HomeTab({
    Key? key,
  }) : super(key: key);

  @override
  State<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> {
  //final _key = GlobalKey<ScaffoldState>();
  final dio = Dio(BaseOptions(baseUrl: 'https://dummyreddit.glitch.me'));



  Future<All>fetchRepos() async {
    // look at this then run code
    //TODO return loged in user repo...if you can
    final response = await http.get(Uri.parse('https://api.github.com/users/Insitepass/repos'));

    if (response.statusCode == 200) {
      print(response.body);
      return All.fromJson(json.decode(response.body));

    } else {
      throw Exception('Failed to fetch repos!');
    }
  }

  //Future<All> futureRepo;

  @override
  void initState() {
    super.initState();
    fetchRepos();
  }

  @override
  Widget build(BuildContext context) {

    return ListView.builder(
      itemCount: 100,
      itemBuilder: (context, i) {
        return const Text('Repos');
        //TODO show repositories here
        // return Card(
        //   child: FutureBuilder<All>(
        //       future: futureRepo,
        //       builder: (BuildContext context, snapshot) {
        //         if (snapshot.hasData) {
        //           List<Repo> repos = <Repo>[];
        //           for(int i=0; i<snapshot.data.repos?.length; i++) {
        //             repos.add(Repo(
        //               name: snapshot.data.repos[i].name,
        //               description: snapshot.data.repos[i].description,
        //               htmlUrl: snapshot.data.repos[i].htmlUrl,
        //               stargazersCount: snapshot.data.repos[i].stargazersCount,
        //
        //             ));
        //           }
        //           return ListView(
        //               children: repos.map((r) => Card(
        //                   child: Column(children:[
        //                     Text(r.name),
        //                     Text(r.description),
        //                     Text(r.htmlUrl),
        //                     Text(r.stargazersCount.toString()),
        //
        //                   ])
        //               ))
        //                   .toList());
        //
        //
        //         } else if (snapshot.hasError) {
        //           return Center(
        //             child: Text('Error'),
        //           );
        //         }
        //         else {
        //           return Center(child: CircularProgressIndicator(),
        //           );
        //         }
        //       }
        //   ),
        // );
        //
        const Text('Something');
      },
     );
  }
}

class PostScreen extends StatefulWidget {
  @override
  _PostScreenState createState() => _PostScreenState();
}

class _PostScreenState extends State<PostScreen> {
  bool loading = true;
  @override
  void initState() {
    Future.delayed(const Duration(seconds: 2)).then((_) {
      if (mounted) {
        setState(() {
          loading = false;
        });
      }
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: ThemeData(primarySwatch: Colors.blue),
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.close),
            onPressed: () {
              return Navigator.of(context).pop();
            },
          ),
          actions: <Widget>[
            IconButton(
              icon: const Icon(Icons.bookmark),
              onPressed: () {},
            ),
            IconButton(
              icon: const Icon(Icons.more_vert),
              onPressed: () {},
            ),
          ],
        ),
        body: Center(
          child: loading
              ? const CircularProgressIndicator()
              : const Text("Pretend this is a Post"),
        ),
      ),
    );
  }
}
