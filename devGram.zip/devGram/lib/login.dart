
import 'package:flutter/material.dart';
import 'package:flutter_signin_button/button_list.dart';
import 'package:flutter_signin_button/button_view.dart';
import 'package:simple_auth/simple_auth.dart' as simpleAuth;


//import 'package:simple_auth_flutter/simple_auth_flutter.dart';

class login extends StatefulWidget{
  @override
  State<StatefulWidget> createState() => loginState();



}


class loginState extends State<login> {





  void showError(dynamic ex) {
    showMessage(ex.toString());
  }

  void showMessage(String text) {
    var alert =  AlertDialog(content:  Text(text), actions: <Widget>[
      TextButton(
          child: const Text("Ok"),
          onPressed: () {

          })
    ]);
    showDialog(context: context, builder: (BuildContext context) => alert);
  }

//login in using the simpleAuth plugin to open github api (currently giving error)

  final simpleAuth.GithubApi githubApi = simpleAuth.GithubApi(
      "github", "clientId", "clientSecret", "redirect:/",
      scopes: [
        "user",
        "repo",
        "public_repo",
      ]);

  final simpleAuth.BasicAuthApi basicApi =  simpleAuth.BasicAuthApi(
      "github-basic", "https://api.github.com/user");

// login method
  void login(simpleAuth.AuthenticatedApi api) async {
    try{
      var success = await api.authenticate();
      showMessage("Logged in success:$success");
    }
    catch (e) {
      showError(e);
    }
  }




  @override
  Widget build(BuildContext context) {
    // SimpleAuthFlutter.context = context;
    return Scaffold (
        backgroundColor: Colors.blue,
        body: Padding(
            padding: const EdgeInsets.all(10),
            child:ListView(
              children: <Widget>[
                Container(
                  alignment: Alignment.centerLeft,
                  padding: const EdgeInsets.all(10),
                  // add logo here
                ),
                const SizedBox(height: 25),
                Container(
                    alignment: Alignment.centerLeft,
                    padding : const EdgeInsets.all(10),
                    child: const Text(
                      'DevGram',
                      style: TextStyle(
                          fontWeight: FontWeight.w500,
                          fontSize:50,
                          color: Colors.white
                      ),
                    )
                ),
                const SizedBox(
                  height: 20,
                ),
                Container(
                  alignment: Alignment.center,
                  padding : const EdgeInsets.all(10),
                  child: const Text(
                    'Welcome to DevGram',
                    style: TextStyle(
                        fontWeight: FontWeight.w500,
                        fontSize:14,
                        color: Colors.white
                    ),
                  ),
                  //TODO shrink TextBox then add functionality
                ),
                const SizedBox(
                  height:60,
                  //   ),
                  // Container(
                  //   alignment:  Alignment.center,
                  //   padding : const EdgeInsets.all(32),
                  //   child:   TextField(
                  //     style: TextStyle(color:Colors.white),
                  //     decoration: InputDecoration(
                  //       border: OutlineInputBorder(
                  //         borderSide: const BorderSide(color: Colors.white)
                  //       ),
                  //       hintStyle: TextStyle(color:Colors.white),
                  //       labelText: "Github username"
                  //     )
                  //
                  //     )
                ),


                Container(
                    alignment:  Alignment.center,
                    padding : const EdgeInsets.all(10),
                    child:   SignInButton(
                        Buttons.GitHub,
                        text: "Sign up with GitHub",
                        onPressed: () {
                          //called method
                          login(githubApi);

                        }

                      //sign it with github account
                    )
                )


              ],
            )


        )

    );
  }
}








