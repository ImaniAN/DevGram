library secretkeys;

const github_client_ID= "b12c742de1674a1261de";
const github_client_secret = "d61ab1ab653b714facdba6baeb8c1191d61a1cfd";