package com.devgram.devgram

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
